# Laundry Wallah / Laundry Mart

This is my Task 2 HTML project for the MERN Stack course.

## Project Description

Laundry Wallah / Laundry Mart is a simple laundry service webpage created using HTML.

The webpage contains:
- Laundry Mart introduction
- Laundry image
- Laundry services
- Service price list

## Technologies Used

- HTML5

## Author

Shiva Kumar